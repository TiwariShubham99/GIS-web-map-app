## Project Structure
- `backend/` : Node.js Express API
- `public/` : Leaflet map visualization

## Goto `backend/` : run "node server.js"
- you will see:
- Server running on http://localhost:5000