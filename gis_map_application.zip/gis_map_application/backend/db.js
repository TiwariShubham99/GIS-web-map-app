
const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'GIS_DB',
  password: 'postgres',
  port: 5432,
});

module.exports = pool;
